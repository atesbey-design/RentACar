﻿/*Created By Engin Yenice
enginyenice2626@gmail.com*/

namespace Core.Entities
{
    public interface IEntity
    {
    }
}