﻿/*Created By Engin Yenice
enginyenice2626@gmail.com*/

/*
Created By Engin Yenice
enginyenice2626@gmail.com
*/

using Core.DataAccess;
using Entities.Concrete;
using Entities.Dtos;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace DataAccess.Abstract
{
    public interface IRentalDal : IEntityRepository<Rental>
    {
        List<RentalDetailDto> GetAllRentalDetails(Expression<Func<Rental, bool>> filter = null);
    }
}